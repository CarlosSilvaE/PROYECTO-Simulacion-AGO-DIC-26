"""C: registro, inicio y cierre de sesión."""
import re

from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app.models import usuario_model

bp = Blueprint("auth", __name__)

_CORREO = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@bp.route("/")
def inicio():
    return redirect(url_for("menu.principal" if "usuario_id" in session else "auth.login"))


@bp.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "")
        confirmar = request.form.get("confirmar", "")

        errores = []
        if not 2 <= len(nombre) <= 100:
            errores.append("Escribe tu nombre (entre 2 y 100 caracteres).")
        if not _CORREO.match(correo) or len(correo) > 150:
            errores.append("Escribe un correo válido.")
        if len(password) < 8:
            errores.append("La contraseña debe tener al menos 8 caracteres.")
        if password != confirmar:
            errores.append("Las contraseñas no coinciden.")

        if not errores:
            usuario_id = usuario_model.crear(nombre, correo, password)
            if usuario_id is None:
                errores.append("Ese correo ya tiene una cuenta. Inicia sesión.")
            else:
                session.clear()
                session["usuario_id"] = usuario_id
                session["nombre"] = nombre
                return redirect(url_for("menu.principal"))

        for e in errores:
            flash(e, "error")
        return render_template("registro.html", nombre=nombre, correo=correo)

    return render_template("registro.html", nombre="", correo="")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "")
        usuario = usuario_model.autenticar(correo, password)
        if usuario:
            session.clear()
            session["usuario_id"] = usuario["usuario_id"]
            session["nombre"] = usuario["nombre"]
            return redirect(url_for("menu.principal"))
        flash("Correo o contraseña incorrectos.", "error")
        return render_template("login.html", correo=correo)
    return render_template("login.html", correo="")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
